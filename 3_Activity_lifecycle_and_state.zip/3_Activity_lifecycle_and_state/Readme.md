# 2.2: Activity lifecycle and state

* Task 1: Add lifecycle callbacks to TwoActivities -->*(Project: TwoActivities)*
* Task 2: Save and restore the Activity instance state -->*(Project: TwoActivitiesV2)*
* Coding challenge -->*(Project: ShoppingList)*
* Homework -->*(Project: ManagingStateHW)*
